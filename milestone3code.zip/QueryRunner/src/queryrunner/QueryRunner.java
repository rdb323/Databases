/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class 
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {

    
    public QueryRunner()
    {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error="";
    
        
        // TODO - You will need to change the queries below to match your queries.
        
        // You will need to put your Project Application in the below variable
        
        this.m_projectTeamApplication="STROKE PATIENTS";    // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        
        // Each row that is added to m_queryArray is a separate query. It does not work on Stored procedure calls.
        // The 'new' Java keyword is a way of initializing the data that will be added to QueryArray. Please do not change
        // Format for each row of m_queryArray is: (QueryText, ParamaterLabelArray[], LikeParameterArray[], IsItActionQuery, IsItParameterQuery)
        
        //    QueryText is a String that represents your query. It can be anything but Stored Procedure
        //    Parameter Label Array  (e.g. Put in null if there is no Parameters in your query, otherwise put in the Parameter Names)
        //    LikeParameter Array  is an array I regret having to add, but it is necessary to tell QueryRunner which parameter has a LIKE Clause. If you have no parameters, put in null. Otherwise put in false for parameters that don't use 'like' and true for ones that do.
        //    IsItActionQuery (e.g. Mark it true if it is, otherwise false)
        //    IsItParameterQuery (e.g.Mark it true if it is, otherwise false)
        
        m_queryArray.add(new QueryData("Select p.patient_ID, p.pt_firstname, p.pt_lastname, p.dys_Lvl, food_name,"
        		+ " food_calories from patient p JOIN patHasFood phf on p.patient_ID = phf.patient_ID Join foodItem f"
        		+ " on f.food_ID = phf.food_ID where f.food_calories <= ? Order by p.patient_ID", new String [] {"food_calories"}, new boolean [] {false}, false, true));   
        m_queryArray.add(new QueryData("SELECT * FROM foodItem WHERE food_carb < ?", new String [] {"food_carb"}, new boolean [] {false},  false, true));
        m_queryArray.add(new QueryData("SELECT patient_ID, pt_firstname, pt_lastname, pt_DOB, dys_Lvl FROM patient"
        		+ " Where pt_DOB < ? AND dys_Lvl = ? ORDER BY patient_ID", new String [] {"pt_DOB", "dys_Lvl"}, new boolean [] {false, false}, false, true));
        m_queryArray.add(new QueryData("SELECT t.physician_ID, concat(p.phy_firstname, ' ', p.phy_lastname) as DoctorName, count(pt.patient_ID) as NumOfPatients" + 
        		" FROM Team t JOIN physician p ON t.physician_ID = p.physician_ID JOIN patient pt ON pt.patient_ID = t.patient_ID" + 
        		" WHERE pt.pt_DOB < ? GROUP BY t.physician_ID",new String [] {"pt_DOB"}, new boolean [] {false}, false, true));
        m_queryArray.add(new QueryData("SELECT patient_ID, pt_firstname, pt_lastname, pt_DOB, dys_Lvl"
        		+ "	FROM patient Where pt_DOB < ? AND dys_Lvl < ? ORDER BY patient_ID", new String[] {"pt_DOB", "dys_Lvl"}, new boolean[] {false, false}, false, true));
        m_queryArray.add(new QueryData("SELECT phy.physician_ID, phy_firstname, phy_lastname, phy.phy_practice_length FROM physician phy " + 
        		"WHERE phy.phy_practice_length > ? ORDER BY phy.physician_ID",new String [] {"phy_practice_length"}, new boolean [] {false}, false, true));
        m_queryArray.add(new QueryData("INSERT INTO patient (patient_ID, pt_firstname, pt_lastname, pt_weight, pt_height, pt_blood_type, pt_DOB, dys_Lvl) "
        		+ "values (?, ?, ?, ?, ?, ?, ?, ?)",new String [] {"patient_ID", "pt_firstname","pt_lastname", "pt_weight", "pt_height", "pt_blood_type", "pt_DOB", "dys_Lvl"},
        		new boolean [] {false, false, false, false, false, false, false, false}, true, true));
        m_queryArray.add(new QueryData("SELECT * FROM patient WHERE patient_ID = ?", new String [] {"patient_ID"}, new boolean [] {false},  false, true));
        /*
          * Did # 1-2, and 4-7             
          */
    }
       

    public int GetTotalQueries()
    {
        return m_queryArray.size();
    }
    
    public int GetParameterAmtForQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }
              
    public String  GetParamText(int queryChoice, int parmnum )
    {
       QueryData e=m_queryArray.get(queryChoice);        
       return e.GetParamText(parmnum); 
    }   

    public String GetQueryText(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetQueryString();        
    }
    
    /**
     * Function will return how many rows were updated as a result
     * of the update query
     * @return Returns how many rows were updated
     */
    
    public int GetUpdateAmount()
    {
        return m_updateAmount;
    }
    
    /**
     * Function will return ALL of the Column Headers from the query
     * @return Returns array of column headers
     */
    public String [] GetQueryHeaders()
    {
        return m_jdbcData.GetHeaders();
    }
    
    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     * @return multi-dimensional array of String data based on the resultset 
     * from the query
     */
    public String[][] GetQueryData()
    {
        return m_jdbcData.GetData();
    }

    public String GetProjectTeamApplication()
    {
        return m_projectTeamApplication;        
    }
    public boolean  isActionQuery (int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }
    
    public boolean isParameterQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryParm();
    }
    
     
    public boolean ExecuteQuery(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
        return bOK;
    }
    
     public boolean ExecuteUpdate(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }   
    
      
    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase)
    {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (bConnect == false)
            m_error = m_jdbcData.GetError();        
        return bConnect;
    }
    
    public boolean Disconnect()
    {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return true;
    }
    
    public String GetError()
    {
        return m_error;
    }
 
    private QueryJDBC m_jdbcData;
    private String m_error;    
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;  
    private int m_updateAmount;
            
    /**
     * @param args the command line arguments
     */
    

    
    public static void main(String[] args) {
        // TODO code application logic here

        final QueryRunner queryrunner = new QueryRunner();
        
        if (args.length == 0)
        {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {

                    new QueryFrame(queryrunner).setVisible(true);
                }            
            });
        }
        else
        {
            if (args[0].equals ("-console"))
            { 
            	QueryRunner qr = new QueryRunner();
            	qr.Connect("cs100.seattleu.edu", "mm_sttest4b", "mm_sttest4bPass", "mm_sttest4b");
                int n = qr.GetTotalQueries();
                boolean bOK = true;
                for (int i=0;i < n && bOK; i++)
                {                	
                	String[] params = null;
                	if(qr.isParameterQuery(i)) {
                		Scanner scn = new Scanner(System.in);
                		int amn = qr.GetParameterAmtForQuery(i);
                		params = new String[amn];
                		for(int j = 0; j < amn; j++) {
                			System.out.println("What would you like the value of the parameter " + qr.GetParamText(i, j) + " to be?");
                			params[j] = scn.nextLine();
                		}
                	}
                	if(qr.isActionQuery(i)) {
                		bOK = qr.ExecuteUpdate(i, params);
                		if(bOK) {
                			System.out.println("Query successfull! There have been " + qr.GetUpdateAmount() + " rows affected.");
                		}
                	}
                	else {
                		bOK = qr.ExecuteQuery(i, params);
                		if(bOK) {
                			System.out.println("Query ran successfully, printing the results:");
                			String[] colHeads = qr.GetQueryHeaders();
                			for(String head : colHeads) {
                				System.out.print(head + "  ");
                			}
                			System.out.println();
                			String[][] results = qr.GetQueryData();
                			for(String[] row : results) {
                				for(String single : row) {
                					System.out.print(single + "  ");
                				}
                				System.out.println();
                			}
                		}
                	}
                	
                	if(!bOK) {
                		System.out.println("Query failed with an error");
                	}
                }
                qr.Disconnect();


                // NOTE - IF THERE ARE ANY ERRORS, please print the Error output
                // NOTE - The QueryRunner functions call the various JDBC Functions that are in QueryJDBC. If you would rather code JDBC
                // functions directly, you can choose to do that. It will be harder, but that is your option.
                // NOTE - You can look at the QueryRunner API calls that are in QueryFrame.java for assistance. You should not have to 
                //    alter any code in QueryJDBC, QueryData, or QueryFrame to make this work.
//                System.out.println("Please write the non-gui functionality");
                
            }
        }
 
    }    
}
